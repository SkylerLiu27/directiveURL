export class Url {
    id: number;
    url: string;
}