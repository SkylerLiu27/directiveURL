RedirectApp directiveURL.zip contains the whole project.
This project was generated with Angular CLI version 7.3.0.

Installing the whole project
Run npm install to install node_module file

Running project
Run npm start to initialize and run the project Run port on "4200"

Running unit tests
Run ng test to execute the unit tests via Karma.

complete
Use LocalStorage to store the url and tinyUrl

ues service to get and store data, use key, value pair to store (id : key; url : value)

When write the tinyUrl in the address bar to reditive to the corresponding url

Use the Angular Router to navigate from inputcomponent to redirectcomponent. At the same time, the user gets the id from part of tiny to nagivate to the new page.
